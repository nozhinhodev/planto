// Информация о регионах Узбекистана
var regionsData = {
    "region1": { name: "Регион 1", climate: "Климат 1", usage: "Использование в агро проектах 1" },
    "region2": { name: "Регион 2", climate: "Климат 2", usage: "Использование в агро проектах 2" },
    // Добавьте данные для других регионов
};

// Инициализация карты
var map = L.map('map').setView([41.3775, 64.5853], 6);

// Добавление карты OpenStreetMap в качестве базовой карты
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Загрузка геоданных регионов
L.geoJson.ajax("uzbekistan.geojson", {
    style: function (feature) {
        return { fillColor: getRandomColor(), weight: 2, opacity: 1, color: 'white', dashArray: '3', fillOpacity: 0.7 };
    },
    onEachFeature: function (feature, layer) {
        layer.on('click', function (e) {
            displayRegionInfo(feature.properties.id);
        });
    }
}).addTo(map);

// Отображение информации о регионе при клике
function displayRegionInfo(regionId) {
    var regionInfo = regionsData[regionId];
    if (regionInfo) {
        alert(`Регион: ${regionInfo.name}\nКлимат: ${regionInfo.climate}\nИспользование в агро проектах: ${regionInfo.usage}`);
    }
}

// Генерация случайного цвета для заливки регионов
function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
// Информация о цветах для каждой области
var regionColors = {
    "region1": "#FF5733",
    "region2": "#33FF57",
    // Добавьте цвета для других областей
};

// Отображение каждой области в виде блока с цветом
Object.keys(regionColors).forEach(function (regionId) {
    var regionElement = document.createElement('div');
    regionElement.id = regionId;
    regionElement.style.width = '100px';
    regionElement.style.height = '100px';
    regionElement.style.backgroundColor = regionColors[regionId];
    regionElement.style.margin = '10px';
    regionElement.style.display = 'inline-block';

    regionElement.addEventListener('click', function () {
        displayRegionInfo(regionId);
    });

    document.getElementById('map').appendChild(regionElement);
});

// Отображение информации о регионе при клике
function displayRegionInfo(regionId) {
    var regionInfo = regionsData[regionId];
    if (regionInfo) {
        alert(`Регион: ${regionInfo.name}\nКлимат: ${regionInfo.climate}\nИспользование в агро проектах: ${regionInfo.usage}`);
    }
}