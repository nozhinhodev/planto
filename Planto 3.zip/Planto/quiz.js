var currentQuestion = 0;
var totalQuestions = 5; // Общее количество вопросов

// Массив с вопросами
var questions = [
    "Muayyan hudud uchun optimal ekinlarni tanlashga qanday omillar ta'sir qiladi?",
    "Qishloq xo'jaligiga genetik modifikatsiyalangan organizmlarni kiritishda qanday afzalliklar va kamchiliklar mavjud?",
    "Qanday zararkunandalarga qarshi kurash usullari eng samarali va ekologik jihatdan qulay?",
    "Qishloq xo'jaligining aniq texnologiyalari resurslar samaradorligini oshirishga qanday yordam berishi mumkin?",
    "Qishloq xo'jaligi mahsulotlarini saqlash va tashishning qanday innovatsion usullari mavjud?"
];

function startQuiz() {
    displayQuestion();
}

function nextQuestion() {
    var form = document.getElementById('quiz-form');
    var answer = getSelectedAnswer(form);

    // Ваша логика проверки ответов и присвоения уровней знаний
    // В данном примере, просто переходим к следующему вопросу
    currentQuestion++;

    if (currentQuestion < totalQuestions) {
        displayQuestion();
    } else {
        showResult();
    }
}

function displayQuestion() {
    var questionElement = document.getElementById('question');
    questionElement.textContent = questions[currentQuestion];

    // Очищаем ответы
    var form = document.getElementById('quiz-form');
    form.innerHTML = '';

    // Создаем новые радиокнопки с вариантами ответов
    for (var i = 1; i <= 3; i++) {
        var label = document.createElement('label');
        var input = document.createElement('input');
        input.type = 'radio';
        input.name = 'answer';
        input.value = 'Вариант ' + i;

        label.appendChild(input);
        label.appendChild(document.createTextNode('Вариант ' + i));

        form.appendChild(label);
    }

    // Добавляем кнопку для перехода к следующему вопросу
    var button = document.createElement('button');
    button.type = 'button';
    button.textContent = 'Следующий вопрос';
    button.onclick = nextQuestion;
    form.appendChild(button);
}

function getSelectedAnswer(form) {
    var answers = form.elements['answer'];

    for (var i = 0; i < answers.length; i++) {
        if (answers[i].checked) {
            return answers[i].value;
        }
    }

    return null;
}

function showResult() {
    // Ваша логика для определения уровня знаний и перехода на соответствующую страницу
    // В данном примере, просто выводим сообщение
    alert('Спасибо за прохождение опроса!');
}

// Запускаем опрос при загрузке страницы
startQuiz();