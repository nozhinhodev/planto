from flask import Flask, render_template_string, request, jsonify
import openai

openai.api_key = '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'  # Replace with your OpenAI API key

app = Flask(__name__)

# HTML content for the chat interface
chat_interface = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Interface</title>
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
input{
padding: 10px 60px;
}
body{
font-family: 'Montserrat', sans-serif;
display: flex;
flex-direction: column;
justify-content: center;
width:100%
text-align: center;
align-items:center;
}
button{
padding: 10px 30px;
}
p{
text-align:center;
align-items:center;
}
</style>

<body>
    <h1>Chat Interface</h1>
    <div id="chat-container">
        <div id="chat-display"></div>
        <input type="text" id="user-input" placeholder="Type your message...">
        <button onclick="sendMessage()">Send</button>
    </div>

    <script>
        function sendMessage() {
            var userMessage = document.getElementById('user-input').value;
            document.getElementById('user-input').value = '';

            // Display user message in the chat
            var chatDisplay = document.getElementById('chat-display');
            chatDisplay.innerHTML += '<p>User question: ' + userMessage + '</p>';

            // Send user message to the server
            fetch('/ask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 'question': userMessage }),
            })
            .then(response => response.json())
            .then(data => {
                // Display server response in the chat
                chatDisplay.innerHTML += '<p>Server: ' + data.response + '</p>';
            });
        }
    </script>
</body>
</html>
"""


# Render the chat interface
@app.route('/')
def chat():
    return render_template_string(chat_interface)


# API endpoint for processing user questions
@app.route('/ask', methods=['POST'])
def ask_question():
    if request.method == 'POST':
        data = request.get_json()
        if 'question' in data:
            question = data['question']

            completion = openai.Completion.create(
                engine="text-davinci-003",
                prompt=question,
                max_tokens=1000
            )
            response = completion.choices[0].text.strip()

            return jsonify({'response': response})
        else:
            return jsonify({'error': 'No question provided'}), 400
    else:
        return jsonify({'error': 'Invalid request method'}), 405


if __name__ == '__main__':
    app.run(debug=True, port=8080)

